                     ****************************************************
                     *  Mocha TN3270 for Windows 7/10/11 version 4.2    *
                     *   Copyright (C) MochaSoft Aps                    *
                     *       All Rights Reserved                        *
                     ****************************************************
 
This is the README.TXT  file for Mocha TN3270 for Windows 7/8/10/11

Mocha TN3270 provides TN3270 emulation for IBM Mainframe access.
 
The target OS is the Microsoft Windows 7/8/10/11 platform and .NET 4.7.2

Versions before 2.2 can be used with XP, if .NET 4.0 is installed



*** Order ***
    
    Visit www.mochasoft.dk for latest information. You can order with
    Credit card or bank transfer.

*** Installation ***

    - click on tn3270.msi 


To make a silent installation run

      tn3270.msi /quiet

    To copy an already made configuration file (user.config) 
    to the users private folders at the installation

      tn3270.msi   CONFIG=c:\user.config
   


*** Uninstallation ***

    Use Windows tool "Add/Remove Programs" in the Control Panel. 

*** Documentation ***

    The documentation has been included in the Window Help
    system. Select Help in the menu.

*** Bugs ***

  If any bugs are observed, or ideas for improvement of the product,
  please to not hesitate to contact support@mochasoft.dk.

*** Change list ***

version 1.0 : 25 May 2007

  First version.

Version 1.1 : 1 June 2007
 
 - a space before or after the IP address in the connect dialog, would
   make the DNS lookup fail
 - description in the desktop shortcut was wrong
 - new color for the icons

Version 1.2 : 19 July 2007
 - solved issued with roaming user profiles. V 1.1 could not handle
   roaming. If upgrading from v 1.1, and roaming on the PC is enabled
   the old tn3270 configuration will be lost.

Version 1.3 : 27 January 2009
 - AID for read buffer command could be wrong

version 1.5 : 10 November 2009
 - if user.config file was deleted, the program could not start
 - problem with extended highlighting and default request in a Modify field order
 - PA1,PA2 and PA3 was missing in the keyboard configuration 

version 1.6 : 7 October 2010
 - altgr+v would make a crash on Vista
 - clipboard csv format failed with some 8 bit characters
 - 2 x click on printer icon in toolbar could give a crash
 - append now includes CR LF
 - http: possible as start of a hotspot
 - moving mouse to the left of the window, when selecting an area could give a crash
 - character & in a screen would make menu - file - mail fail

version 1.7 :  9 June 2011
 - closing windows with a click on [x], will make the .NET close the connection to the IBM mainframe. 
   Now the 3270 code force the closing, if possible.

version 1.8 :  30 June 2011
 - new SSL layer. Now the SSL which is part of the Windows OS .NET is used
 - use parameter 

    tn3270.msi   CONFIG=c:\user.config

   to copy a configuration file to the users private files at installation.

 - % and & has been removed from data send to the mail program.
 - f20 - f24 did not work in the tool bar
 - added fixed width option for fonts. Some .NET installations does not handle the font API correct. 
   This option makes sure the font stays the same width , also when changing the 3270 window width.
 
version 1.9 : 9 July 2012
 - if clipboard was locked from another program, tn3270 could crash
 - NEWLINE in a macro, would also add a NEXT function
 - SelecXXXX is missing in the keyboard configuration table
 - ctrl+f12 would give a crash
 
version 2.0 , 20 Marts 2013
 - Greek codepage was wrong
 - new parameter /Y ( use a local user.config file)
 - space in IP address, or license key would give error
 - left ctrl can work as reset and normal 2 key combination as ctrl + c 
 - added menu - edit - paste as Text format

version 2.1 , 27 january 2015
 - uses .NET 4.0

version 2.2, 22 May 2015
 - TN3270E protocol and LU name support
 - If the font and OS support it, extra space horizontal will be allowed between characters.
 - General bug fixing

version 2.3, 7 June 2015
 - Ignores IPv6 DNS replies
 - Requires .NET 4.5 , as to support TLS 1.2
 - SSL/TLS version is shown in the status line.
 - Cannot be used with XP, as XP only supports .NET 4.0

version 2.4 , 2 Feb. 2016
 - menu - file - connect , could fail
 - paste text including ",." after using keypad could give wrong data (,. swapped)
 
version 2.5 , July 5 2016
 - added IPv6 support

version 2.6 , July 26 2017
 - Query reply now includes the CGCSGID (codepage) value

version 2.6.1 and 2.6.2 , July 27 2017
 - more work on Query reply
 
version 2.7 , 30 September 2017
 - added option menu - file - edit/new session : Verify server certificate

version 2.8 , 31 Okctober 2017
 - solved problem with , and excel paste with delimiter ";"

version 2.9 , 10 April 2018
 - ctrl+a as select all
 - in menu - tools - keyboard layout, a macro can be linked to a key.

version 3.0 , 11 April 2018
 - If tn3270 has been used on a 2 monitor system,
   and the second monitor is removed, tn3270 would on next program start, 
   try to run on the second monitor.

version 3.1, 15 August 2018
 - In some environments, tn3270 could crash when accessing the clipboard

version 3.1.1 15 December 2018
 - changed query reply data

version 3.2 , 13 March 2020
 - LUNAME was limited to size 8

version 3.3 June 2020
 - added codepage 1047
 - swapped ebdic AE and 8E  ( Þ <--> þ )
 - print preview had problems with some printer drivers
 - print will include underlined text

version 3.4 july 2020
 - added new screen sizes 43x80 and 27x132

version 3.5 , November 2021
- add HOME key function
- when using TLS, keep alive is also possible

version 3.6, February 2023
- added date/time stamp option for screen print

version 3.7.1, March 21 2023
- updated to .NET 4.7.2 , as to support TLS 1.3

version 3.7.2, Maj 16 2023
- Updated the tn3270e protocol

version 3.8, June 17 2023
- Added IND$FILE protocol in menu - tools

version 3.9, June 26 2023
- If using UK (285) codepage, IND$FILE is IND£FILE

version 3.9.1 Auguest 2 2023
- test version for special tn3270e protocol

version 3.9.2 August 16 2023
- ind$file send to server, could in special cases fail and display many messages telling the transfer was completed.

version 3.9.3 October 13 2023
- better error handling at installation.

version 4.0 June 2024
- added function "send text to cursor" at double click

version 4.1 September 2024
- Calling a macro from a key, would only play the macro until keyboard was locked, such as after a ENTER key.
- LAST and BEGIN functions did not work correct. 

version 4.2 September 2025
- added new option in menu - tools - options - printer : Use printer driver margin settings.  

The Mocha TN3270 package consists of the following files.

    README.TXT          Introductory information
    mtn3270.chm         Help file
    tn3270.exe          tn3270 program   
    ebcdic.037          EBCDIC <-> ASCII table US (ASCII file)
    ebcdic.280          EBCDIC <-> ASCII table Italy (ASCII file)
    ebcdic.273          EBCDIC <-> ASCII table Austria/Germany (ASCII file)
    ebcdic.284          EBCDIC <-> ASCII table Spain (ASCII file)
    ebcdic.297          EBCDIC <-> ASCII table French (ASCII file)
    ebcdic.285          EBCDIC <-> ASCII table United Kingdom (ASCII file)
    ebcdic.1025         EBCDIC <-> ASCII table Russian (ASCII file)
    ebcdic.278          EBCDIC <-> ASCII table Finland/Sweden (ASCII file)
    ebcdic.871          EBCDIC <-> ASCII table Iceland (ASCII file)
    ebcdic.277          EBCDIC <-> ASCII table Danish/Norway (ASCII file)
    ebcdic.870          EBCDIC <-> ASCII table EastEurope (**) (ASCII file)
    ebcdic.875          EBCDIC <-> ASCII table Greek (ASCII file)
    ebcdic.1026         EBCDIC <-> ASCII table Turkish (ASCII file)
    ebcdic.274          EBCDIC <-> ASCII table Belgium (ASCII file)
    ebcdic.385          EBCDIC <-> ASCII table French Canadian (ASCII file)
    ebcdic.500          EBCDIC <-> ASCII table codepage 500 (ASCII file)
   
    If you did not receive all these files please contact 
    support@mochasoft.dk, or check www.mochasoft.dk
